﻿using HutongGames.PlayMaker;
using UnityEngine;
using System.Collections;
using System;

/**
 * PlayMaker custom action
 * Based on code by Jonathan O'Duffy and Andrew Jones - Fantasy to Reality - http://www.fantasytoreality.com.au/
 */
namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Kinect Actions")]
	[Tooltip("Allows you to track face params (AnimationUnits), recognized by the Kinect facetracking manager.")]
	
	public class TrackFaceParams : FsmStateAction
	{
//		public enum PlayMakerUpdateCallType {Update,LateUpdate,FixedUpdate};
//		[Tooltip("Allow the user to determine which update to use.")]
//		public PlayMakerUpdateCallType updateCall;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store boolean, if the face is currently tracked or not.")]
		public FsmBool isFaceTracked;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the head position, if the face is tracked.")]
		public FsmVector3 headPosition;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the head rotation, if the face is tracked.")]
		public FsmQuaternion headRotation;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the face AnimUnit0, if the face is tracked.")]
		public FsmFloat faceAU0;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the face AnimUnit1, if the face is tracked.")]
		public FsmFloat faceAU1;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the face AnimUnit2, if the face is tracked.")]
		public FsmFloat faceAU2;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the face AnimUnit3, if the face is tracked.")]
		public FsmFloat faceAU3;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the face AnimUnit4, if the face is tracked.")]
		public FsmFloat faceAU4;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the face AnimUnit5, if the face is tracked.")]
		public FsmFloat faceAU5;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the face AnimUnit6, if the face is tracked.")]
		public FsmFloat faceAU6;
		
		[UIHint(UIHint.Variable)]
		[Tooltip("Variable to store the face AnimUnit7, if the face is tracked.")]
		public FsmFloat faceAU7;
		
		[Tooltip("Custom event to be sent when the face tracking is started.")]
		public FsmEvent facetrackingStartedEvent;
		
		[Tooltip("Custom event to be sent when the face tracking is stopped.")]
		public FsmEvent facetrackingStoppedEvent;
		
		private FacetrackingManager manager;
		

		// called when the state becomes active
		public override void OnEnter()
		{			
			isFaceTracked.Value = false;
		}
		
		public override void OnExit ()
		{
			if(isFaceTracked.Value)
			{
				isFaceTracked.Value = false;
				Fsm.Event(facetrackingStoppedEvent);
			}
		}
		
//		public override void OnLateUpdate()
//		{
//			if (updateCall == PlayMakerUpdateCallType.LateUpdate)
//			{
//				checkFacetrackingStatus();			
//			}
//		}
//		
//		public override void OnFixedUpdate()
//		{
//			if (updateCall == PlayMakerUpdateCallType.FixedUpdate)
//			{
//				checkFacetrackingStatus();			
//			}
//		}
		
		public override void OnUpdate()
		{
//			if (updateCall == PlayMakerUpdateCallType.Update)
			{
				checkFacetrackingStatus();			
			}
		}
		
		private void checkFacetrackingStatus()
		{		
			if(manager == null)
			{
				manager = FacetrackingManager.Instance;
			}
			
			if(manager != null && manager.IsFacetrackingInitialized())
			{
				bool bPrevFaceTracking = isFaceTracked.Value;
				
				if(manager.IsTracking())
				{
					isFaceTracked.Value = true;
					
					headPosition.Value = manager.GetHeadPosition();
					headRotation.Value = manager.GetHeadRotation();
					
					int iAuCount = manager.GetAnimUnitsCount();
					
					if(iAuCount >= 6)
					{
						faceAU0.Value = manager.GetAnimUnit(0);
						faceAU1.Value = manager.GetAnimUnit(1);
						faceAU2.Value = manager.GetAnimUnit(2);
						faceAU3.Value = manager.GetAnimUnit(3);
						faceAU4.Value = manager.GetAnimUnit(4);
						faceAU5.Value = manager.GetAnimUnit(5);
					}
					
					if(iAuCount >= 8)
					{
						faceAU6.Value = manager.GetAnimUnit(6);
						faceAU7.Value = manager.GetAnimUnit(7);
					}
					else
					{
						faceAU6.Value = 0f;
						faceAU7.Value = 0f;
					}
					
					if(!bPrevFaceTracking)
					{
						Fsm.Event(facetrackingStartedEvent);
					}
				}
				else
				{
					isFaceTracked.Value = false;
					
					if(bPrevFaceTracking)
					{
						Fsm.Event(facetrackingStoppedEvent);
					}
				}
			}
		}
	}
}